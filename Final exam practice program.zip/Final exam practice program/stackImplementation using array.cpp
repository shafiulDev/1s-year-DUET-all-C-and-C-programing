#include <bits/stdc++.h>
using namespace std;
class Stack{

public:

	int max=10;
	int arr[10], top=0;

	int push(int a){
		arr[++top]=a;
		return arr[top];
	}
	int pop(){
		arr[--top];
		return arr[top];

	}
	void display(){
		for(int i=1; i<=top; i++){
			cout<<arr[i]<<" ";
		}
	}
};
int main(){
	Stack s1;
	s1.push(10);
	s1.push(164);
	s1.push(123);
		s1.pop();
	s1.push(341);

	s1.push(45);
	s1.push(54);
	s1.push(121);
		s1.pop();
	s1.push(12);
	s1.push(143);
	s1.pop();
	s1.pop();
	s1.pop();
s1.display();
}
