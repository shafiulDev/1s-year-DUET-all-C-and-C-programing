#include <bits/stdc++.h>
using namespace std;
class Boys{
private:
	int age,roll, reg,dolar;
public:
	Boys():roll(0),reg(0){};
	Boys( int ro, int re):roll(ro),reg(re){};
//plas oparetor overloding;''''''''''''''''''''''''''''''''''''''''''''''''''''
	Boys operator +(Boys a){
		Boys temp;
		temp.roll= roll+a.roll;
		temp.reg= reg+a.reg;
		return temp;
	}

	void display(){
		cout<<"Roll is-"<<roll<<endl<<"Regtation is-"<<reg<<endl;
	}
Boys operator -(Boys a);
};

//using scoperesulatio minus operator overlodding ''''''''''''''''''''''''''''''
Boys Boys::operator -(Boys a){
	Boys temp;
	temp.roll=roll-a.roll;
	temp.reg=reg-a.reg;
	return temp;

}
int main(){
	Boys b1(21,23);
	Boys b2(1,3);
	Boys b5(14),b6(14);

	Boys b3=b1+b2;
	Boys b4=b1-b2;

	b3.display();
	b4.display();
	b5.doldisplay();
}
