#include<bits/stdc++.h>
using namespace std;
const int Max=20;
template<class T>

class Stack{
	T count1[Max];
	int top;
public:
	Stack(){top=-1;}
	T push(T a){
		count1[top+1]=a;
		top+=1;
		return count1[top];

	}
	T pop(){
	count1[--top];
	}
	void display(){
	for(int a=0; a<=top; a++){
		cout<<count1[a]<<" ";
	}
	}


};
int main(){
	Stack <char > s1;
	s1.push('A')
	s1.push('Z');
	s1.push('1');
	s1.push(9);
	s1.pop();
	s1.push('a');
	s1.push('z');
	s1.push('5');
	s1.display();

	return 0;
}
