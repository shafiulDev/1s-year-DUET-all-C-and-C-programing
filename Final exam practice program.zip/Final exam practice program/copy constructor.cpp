#include <bits/stdc++.h>
using namespace std;
class Distance{
	private:
int feet,num;
double inch;


public:
	static int a;
	Distance():feet(0),inch(0.0){}
	Distance(int f, float i):feet(f),inch(i){}
	void getdist()
	{
	cout << "\nEnter feet: "; cin >> feet;
	cout << "Enter inches: "; cin >> inch;
	}



	void num1()const{

	cout<<feet<<endl;
	}
	void printdist(){


		cout<<feet<<"\'-"<<inch<<'\"'<<endl;
	}


};
int main(){
	Distance f1(10,12.12);
	Distance f2=f1;
	Distance f3(f1);

	Distance n;
	n.getdist();
	n.num1();

	f1.printdist();
	f2.printdist();
	f3.printdist();

}
