

#include<bits/stdc++.h>
using namespace std;
const int Max=5;
class Home{

public:
	int room[3];
	Home(int a, int b, int c, int d){
	room[0]=a;
	room[1]=b;
	room[2]=c;
	room[3]=d;
	}

	int operator [](int posi){
		return room[posi];
	}

};
int main(){
	Home h1(34,45,45,23);

		for(int i=0; i<3; i++){
			cout<<h1[i]<<" ";
		}
}
