#include <bits/stdc++.h>
using namespace std;

class Boys{
private:
    int reg, roll;
public:
    Boys(int i = 0, int re = 0)  {
		roll=i;
		reg=re;
    }
    void Display() {
        cout << roll << "    " << reg << endl;
    }
    friend Boys operator +(double b, Boys a);
};

Boys operator +( double b,Boys a) {
    Boys t;
    t.roll = b+a.roll;
    t.reg = b+a.reg;
    return t;
}

int main() {
    Boys b1(21, 30);
    Boys b2(23, 39);
    Boys b3 = 50+b1;
    b3.Display();
    return 0;
}
