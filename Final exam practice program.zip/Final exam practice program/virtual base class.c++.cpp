#include<bits/stdc++.h>
using namespace std;
class Base{
protected:
	int a;
public:
	Base(){
	a=100;}

};

class Drive1:public virtual Base{//use virtual keyoword------------------
protected:
public:
};

class Drive2:public virtual Base{ //Use virtual keyword -----------------
protected:
public:
};


class Drive3:public Drive1,public Drive2{
protected:

public:
	void display(){
	cout<<a<<endl;
	}

};
int main(){
	Drive3 d3;
	d3.display();


return 0;}
