#include<bits/stdc++.h>
using namespace std;
int main(){
	try{
	int a, b;
	cout<<"Enter the value of a= ";
	cin>>a;
	cout<<"Enter the value of b=";
	cin>>b;
	if(b==0){throw -1;}

	int c=a/b;
	cout<<"The result is = "<<c;
	}
	catch(...){
	cout<<" Please Enter valid number of b\a";
	}
	return 0;
}
