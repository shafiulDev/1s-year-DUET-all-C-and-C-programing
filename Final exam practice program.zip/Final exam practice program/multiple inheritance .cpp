#include<bits/stdc++.h>
using namespace std;
class Base1{
protected:
	int first;
public:
	Base1(int a=0){first=a;}


};
class Base2{
protected:
	int second;
public:
	Base2(int b=0){second=b;}

};
class Drive:public Base1, public Base2{
protected:
	int third;
public:

	Drive(int a,int b, int c):Base1(a),Base2(b){third=c;}
	void display(){
	cout<<first<<"   "<<second<<"   "<<third<<endl;}


};
int main(){

Drive d1(29,23,34);

d1.display();
return 0;}
