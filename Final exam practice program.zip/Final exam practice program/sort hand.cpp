
#include <bits/stdc++.h>
using namespace std;
class Boys{
private:
	int age,roll, reg,dolar;
public:
	Boys():roll(0),reg(0){};
	Boys( int ro, int re):roll(ro),reg(re){};
	Boys(int dol=0){dolar=dol;}

	void operator+=( int next){

		dolar=dolar+next;

	}
		void doldisplay(){
		cout<<"Total dolar is "<<dolar<<endl;
	}


	void display(){
		cout<<"Roll is-"<<roll<<endl<<"Regtation is-"<<reg<<endl;
	}

};

int main(){

	Boys b5(14),b6(14);
	 b5+=20;
	b5.doldisplay();


}

