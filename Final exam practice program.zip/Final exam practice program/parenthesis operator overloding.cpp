////////////// Rang answer===================================================================

//#include<bits/stdc++.h>
//using namespace std;
//
//class Home{
//	int room;
//
//public:
//	Home(int a=10){room=a;}
//	void display(){cout<<"Your mark is "<<room;}
//
//	int operator ()(int n){
//	room=n;
//	return room;
//	}
//
//};
//int main(){
//	Home m1();
//	room=m1(33);
//	m1.display();
//
//
//}
