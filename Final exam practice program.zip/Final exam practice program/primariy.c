#include <stdio.h>
int main(){
int a;
int b=20,c=11;


	a=b=c;
	printf("Your Incriment number is %d%d%d \a\v",a,b,c);
	printf("Your Incriment number is %d%d%d \a\v",a,b,c);
	return 0;
}
