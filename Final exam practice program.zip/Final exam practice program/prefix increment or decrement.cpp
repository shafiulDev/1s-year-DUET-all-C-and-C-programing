#include <bits/stdc++.h>
using namespace std;
class Border {
	int balance;
public:
	Border(int b=0){
	balance=b;}

		void operator++(){
			balance=balance+1;
		}

		void display(){
			cout<<"Your result is :"<<balance<<endl;
		}


		friend void operator--(Border&m);
};
void operator--(Border&m){
	m.balance-=1;
}
int main(){
	Border b1(2000);
	++b1;
	b1.display();
	--b1;
	b1.display();
	--b1;
	b1.display();


	}
