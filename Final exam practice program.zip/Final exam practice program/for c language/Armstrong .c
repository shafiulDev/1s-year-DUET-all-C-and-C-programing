#include <stdio.h>
int main(){
int n,r, tem, sum=0, p=0;
printf("Enter your number: ");
scanf("%d",&n);
	tem=n;
	while(n){
		n=n/10;
		p++;
	}
	n=tem;
	while(n){

		r=n%10;
		n=n/10;
		sum=sum+pow(r,p);

	}
	if(sum==tem)
		printf("This is a Armstrong");
	else
		printf("This is  not Armstrong");
return 0;
}
