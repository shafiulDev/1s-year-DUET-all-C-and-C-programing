#include <stdio.h>
int main(){
	int n,r,rev=0, temp;
	printf("Enter your number= ");
	scanf("%d",&n);
	temp=n;
	while(n){
		r=n%10;
		n=n/10;
		rev=rev*10+r;
		}
	if( rev==temp){
	printf("This is palandrom");}
	else{
		printf("This is not a palandrom");
	}
return 0;
}
