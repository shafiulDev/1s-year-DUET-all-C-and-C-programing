#include <stdio.h>
int main(){

int n,sum=0;

	printf("Enter a valid Number: ");
	scanf("%d",&n);
	for(int i=1; i<=n/2; i++){
		if(n%i==0){
			sum=sum+i;
		}
	}
	if(sum==n)
		printf("This is a perfect number");
	else
		printf("This is now a perfect number");
return 0;
}
