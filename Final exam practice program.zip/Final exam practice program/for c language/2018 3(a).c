#include <stdio.h>
int main(){
	int lab1,lab2;
	printf("Enter your lab1 and lab2 result :");
	scanf("%d%d",&lab1,&lab2);

	if(lab1>=90&&lab2>=90){
		printf("Your grade is A");
	}

	else if((lab1+lab2)>=160){
		printf("Your grade is B");
	}
	else if((lab1+lab2)==140|| (lab1>=50&&lab2>=50)){
		printf("Your grade is C");
	}
	else
		printf("Your are F");

return 0;

}
