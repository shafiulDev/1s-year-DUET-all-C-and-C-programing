#include <stdio.h>
int power(int a,int b);
int main(){
int b, p, result;
printf("Enter the value of Base: ");
scanf("%d",&b);
printf("Enter the value of Power: ");
scanf("%d",&p);

	result=power(b,p);
	printf("Your result is= %d",result);

	return 0;
}
int power(int a , int b){
	if (b==0)
		return 1;
	else
		return (a*power(a,b-1));

}
