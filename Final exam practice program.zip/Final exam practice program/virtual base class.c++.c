#include<bits/stdc++.h>
using namespace std;
class Base{
protected:
	int a;
public:
	void seta(int s){
	a=s;}

};

class Drive1:virtual public base{
protected:
	int b;
public:
	void setb(int s){
	a=s;}

};
class Drive2:virtual public base{
protected:
	int c;
public:
	void setc(int s){
	a=c;}

};

class Drive3:public Drive1,public Drive2{
protected:
	int d;
public:
	//Drive3(int f,int g, int h, int i):Base(a)
	void setb(int d){
	d=s;}
	void display(){
	cout<<a<<" "<<b<<" "<<c<<" "<<d<<endl
	}

};
int main(){
	Drive3 d3(5);
	d3.setb(3);
	d3.seta(5);
	d3.setc(23);

return 0;}
