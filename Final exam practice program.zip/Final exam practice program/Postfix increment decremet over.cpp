#include<bits/stdc++.h>
using namespace std;
class Room{
	int peaple;
public:
	Room(int p=0){peaple=p;}

	Room operator++(int){
		Room duplicate(*this);
		peaple+=1;
		return duplicate;

	}
		void display(){
			cout<<"Number of people:"<<peaple<<endl;
		}



friend Room operator--(Room&p, int);
friend Room operator+(Room&p, int);
};
Room operator+(Room&p,int a){
Room demo;
p.peaple+=200;
return demo;

}
Room operator--(Room&p, int){
	//Room dup(p);
	//p.peaple-=1;
	return Room(p.peaple-1);
}
int main(){
	Room p1(5);
	(p1++).display();
	p1.display();

	(p1--).display();
	p1.display();

}
