#include<bits/stdc++.h>
using namespace std;
class Base{
protected:
	int boy,girl;
public:
	Base(int b=0, int g=0){boy=b;girl=g;}

	void display(){
		cout<<"Total Boys="<<boy<<endl<<"Total Girls="<<girl<<endl;
	}

};

class Drive1:public Base{
protected:
	int common;
public:
	Drive1(int b,int g, int c):Base(b,g){
		common=c;
		}

	void display(){
		Base::display();
		cout<<"Common Member"<<common<<endl;

	}
};

class Drive2:public Drive1{
protected:
	int house;
public:
	Drive2(int b,int g, int c,int h):Drive1(b,g,c){
		house=h;
		}

	void display(){
		Base::display();
		cout<<"Total house="<<house<<endl;

	}
};
int main(){

Base d1(2,3);
Drive1 d11(29,32,12);
Drive2 d21(29,32,12,5);
d21.display();
}
