

#include <bits/stdc++.h>
using namespace std;
class Boys{
private:
	int age,roll, reg,dolar;
public:
	Boys():roll(0),reg(0){};
	Boys( int ro, int re):roll(ro),reg(re){};
	Boys(int dol=0){dolar=dol;}


	Boys *operator ->(void){
	return this;
	}

	void display(){
		cout<<"Roll is-"<<roll<<endl<<"Regtation is-"<<reg<<endl;
	}
	void display1(){
		cout<<"Your dolar is-"<<dolar<<endl;
	}

};

int main(){
	Boys b1(10);
	Boys b2(12);
	b1.display1();
	b2->display1();



}

