#include<bits/stdc++.h>
using namespace std;

 template<class T, class T2>
 T2 sum(T a,T2 b){//je type ar data return korbo ta lekbo sobar age======================
	return a+b;
 }

 int main(){
 	int  a=10; float b=3350.54;

 		cout<<"Your answer is = "<<sum(a,b)<<endl;


 return 0;
 }
