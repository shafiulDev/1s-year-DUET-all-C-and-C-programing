#include<stdio.h>
int main()
{
	int num;
	for(int i = 0; i < 100; i++)
	{
		scanf("%d",&num);

		if(num % 2 == 1) break;

		if(num % 4 == 0) continue;
		else printf("Your number = %d\n",num);
	}
	return 0;
}