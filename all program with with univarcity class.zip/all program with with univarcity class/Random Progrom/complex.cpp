#include <iostream>
#include <cmath>

using namespace std;

class Complex {
private:
    int real;
    int imaginary;
public:
    Complex() {
        real = 0;
        imaginary = 0;
    }

    Complex(int r, int i) {
        real = r;
        imaginary = i;
    }

    void add(Complex c) {
        int r= real + c.real;
        int i = imaginary + c.imaginary;
        cout << "Sum: " << r << " + "<< i<<"i"  << endl;
    }

    void sub(Complex c) {
        int r = real - c.real;
        int i = imaginary - c.imaginary;
        cout << "Difference: " << r << " + " << i <<"i" << endl;
    }

    double modulus() {
        return sqrt(real * real + imaginary * imaginary);
    }

    double argument() {
        return atan2(imaginary, real);
    }

    void display() {
        cout << "The complex number is " << real << " + " << imaginary<<"i" << endl;
    }

    ~Complex() {
        cout << "Complex number destroyed" << endl;
    }
};

int main() {
    Complex c1(3, 4);
    Complex c2(1, 2);

    c1.display();
    c2.display();

    c1.add(c2);
    c1.sub(c2);

    cout << "Modulus of c1: " << c1.modulus() << endl;
    cout << "Argument of c1: " << c1.argument() << endl;

    return 0;
}
