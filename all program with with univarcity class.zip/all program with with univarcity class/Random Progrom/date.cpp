#include <iostream>
#include <string.h>
using namespace std;
 class Time{
private:
int hours, menuits,secounds ;
public:
	Time(): hours(0),menuits(0),secounds(0){}

	Time(int h, int m, int s):hours(h),menuits(m),secounds(s){}

	void display(){
		cout<<hours<<"-"<<menuits<<"-"<<secounds<<endl;
	}
	void add (Time t1, Time t2);
	};

void Time::add(Time t1, Time t2){
	int h=0,m=0, s=0;
	secounds=t1.secounds+t2.secounds;
	if(secounds>60){
		secounds=0;
		m=1;
	}

	menuits=t1.menuits+t2.menuits+m;
	if(menuits>60){
		menuits=0;
		h=1;

	}

	hours=t1.hours+t2.hours+h;

		cout<<hours<<"-"<<menuits<<"-"<<secounds;


}
int main()
{
	Time t3,t1(5,50,20);

	Time t2(5,21,50);

t1.display();
t2.display();
t3.add(t1, t2);


}
