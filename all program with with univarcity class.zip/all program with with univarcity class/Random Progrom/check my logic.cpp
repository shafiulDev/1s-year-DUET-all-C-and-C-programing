#include <iostream>
using namespace std;

void myFun(){

	for(int j=1; j<=10; j++){
		static int a= 10;
		++a;
		cout<<a<<endl;
	}

}

int main(){

	myFun();

}
