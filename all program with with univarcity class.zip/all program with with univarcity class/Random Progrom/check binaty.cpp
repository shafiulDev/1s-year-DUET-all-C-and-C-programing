#include <iostream>
#include <string.h>
using namespace std;
class binary{
private:
	string a;
public:

	void getinput(){
	cout<<"Enter any Number a do you want: ";
	cin>>a;
	}
	void checkBi(){
		for(int i=0; i<a.size(); i++){
			if(a[i]=='0' || a[i]=='1'){
			}
			else{
			cout<<"Not a binary number";
			break;}

			if(i+1==a.size()){
				cout<<"1s Complement value is :"<<complement(a);
			}
		}
	}
	 string complement(string a){
		for(int i=0; i<a.size(); i++){

			if(a[i]=='0'){
				a[i]='1';

			}
			else{
				a[i]='0';
			}
		}
		return a;
	 }


};


int main()
{
	binary b1;
	b1.getinput();
	b1.checkBi();


}
