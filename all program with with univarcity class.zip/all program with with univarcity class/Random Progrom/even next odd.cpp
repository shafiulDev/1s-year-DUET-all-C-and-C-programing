#include <iostream>
using namespace std;
int main(){

	int user[20],even[20],odd[20],n;
	cout<<"Enter a number Do you want to given user input:";
	cin>>n;

	cout<<"Enter your all even of odd Number :";
	for(int i=0; i<n; i++){
		cin>>user[i];
	}

	for(int j=0; j<n; j++){
		if(user[j]%2==0 ){
			even[j]=user[j];
		}
		else{
			odd[j]=user[j];
		}
	}
	for(int i=0; i<n; i++){

		for(int j=0; j<n; i++){

		}
	}




}


//		for(int i=0; i<n; i++){
//			if(user[i]%2==0 && user[i-1]%2!=0 ){
//			cout<<even[i]<<" ";
//		}
//		else{
//			if(user[i]%2==1 && user[i-1]%2!=1 ){
//				cout<<odd[i]<<" ";
//		}
//		}
//	}
