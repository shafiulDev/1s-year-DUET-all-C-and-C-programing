#include <bits/stdc++.h>
using namespace std;
class Bill{
int current,gas,water;
public:
	Bill():current(0),gas(0),water(0){}
	Bill(int c, int g, int w):current(c),gas(g),water(w){}

	void Display(){
		cout<<"curent bil is: "<<current<<endl;

		cout<<"gas bil is: "<<gas<<endl;
		cout<<"water bil is: "<<water<<endl<<endl;

	}

	Bill operator +(Bill r){
		Bill tem;
		tem.current=current+r.current;
		tem.gas=gas+r.gas;
		tem.water=water+r.water;
		return tem;

	}
	Bill operator -(Bill r);


};
Bill Bill:: operator -(Bill r){
		Bill tem;
		tem.current=current-r.current;
		tem.gas=gas-r.gas;
		tem.water=water-r.water;
		return tem;

}
int main(){
 Bill january(800,600,200);
 Bill february(524,420,450);
 cout<<"Only for summetion";
 Bill Total=january+february;
 Total.Display();

cout<<"Only for subtitution";
 Bill Difference=january-february;
 Difference.Display();
}
