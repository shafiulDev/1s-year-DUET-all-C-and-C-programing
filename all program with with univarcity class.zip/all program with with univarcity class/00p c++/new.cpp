#include<iostream>
using namespace std;

class house{

public:
    int room,door;
    house(){}
    house(int r){room=r;}
    house(int r, int d){room=r;door=d;}
    void dis(){cout<<"Rooms: "<<room<<"\tDoors: "<<door<<endl;}
    void dispp(){cout<<"Rooms: "<<room<<endl;}
    int getr(){return room;}
    int getd(){return door;}
    void setr(int r){room=r;}
    void setd(int d){door=d;}
    house operator*(house obj);
    house operator/(house obj);
    house operator%(house obj);
    house operator+=(house obj);
    house operator-=(house obj);
    house operator*=(house obj);
    house operator/=(house obj);
    int operator==(house obj);
    int operator&&(house obj);
    friend house operator++(house &obj,int);
    friend house operator--(house &obj,int);
};

house house::operator*(house obj)
{
    house mul;
    mul.room = room*obj.room;
    mul.door = door*obj.door;
    return mul;
}

house house::operator/(house obj)
{
    house mul;
    mul.room = room/obj.room;
    mul.door = door/obj.door;
    return mul;
}

house house::operator%(house obj)
{
    return (room%obj.room);
}

house house::operator+=(house obj)
{
    return (room = room + obj.room);
}

house house::operator-=(house obj)
{
    return (room = room - obj.room);
}

house house::operator*=(house obj)
{
    return (room = room - obj.room);
}

house house::operator/=(house obj)
{
    return (room = room / obj.room);
}

int house::operator==(house obj)
{
    return (room==obj.room);
}

int house::operator&&(house obj)
{
    return ((room&&obj.room)&&(door&&obj.door));
}
house operator++(house &obj,int)
{
    obj.room++;
    return obj;
}
house operator--(house &obj,int)
{
    obj.room--;
    return obj;
}
house operator++(house &obj)
{
    obj.room++;
    return obj;
}
house operator--(house &obj)
{
    obj.room--;
    return obj;
}

class accesories:house{

public:
    int light,fan;
    accesories(){}
    accesories(int li){light=li;}
    accesories(int l, int f,int r,int d):house(r,d)
    {
        light=l;fan=f;
    }
    void show(){cout<<"Light: "<<light<<"\tFan: "<<fan<<"\t\tRooms: "<<getr()<<"\tDoors: "<<getd()<<endl;}
    accesories operator+(accesories obj);
};
accesories accesories::operator+(accesories obj)
    {
        accesories temp;
        temp.light = light+obj.light;
        temp.fan = fan + obj.fan;
        temp.room = room + obj.room;
        temp.door = door + obj.door;
        return temp;
    }
class features:house{

public:
    int bath,veranda;
    features(){}
    features(int b,int v,int r,int d):house(r,d)
    {
        bath=b;veranda=v;
    }
    void display(){cout<<"Bath's: "<<bath<<"\tVeranda: "<<veranda<<"\tRooms: "<<getr()<<"\tDoors: "<<getd()<<endl;}
    features operator-(features obj);
};
features features::operator-(features obj){
    features temp;
    temp.bath=bath-obj.bath;
    temp.veranda=veranda-obj.veranda;
    temp.room = room - obj.room;
    temp.door = door - obj.door;
    return temp;
}
int main()
{
    cout<<"\nOverloading Plus Operator...\n"<<endl;
    accesories ob(10,20,30,40),ob2(50,40,60,70),ob3;
    ob3 = ob+ob2;
    ob3.show();

    cout<<"\nOverloading Minus Operator...\n"<<endl;
    features ob4(40,80,50,60),ob5(10,20,30,40),ob6;
    ob6 = ob4-ob5;
    ob6.display();

    cout<<"\nOverloading Multiply Operator...\n"<<endl;
    house h1(100,200),h2(20,50),h3,h4;
    h3 = h1*h2;
    h3.dis();

    cout<<"\nOverloading Division Operator...\n"<<endl;
    h4 = h1/h2;
    h4.dis();

    cout<<"\nOverloading Modulus Operator...\n"<<endl;
    house hm1(20),hm2(3),hm3;
    hm3 = hm1%hm2;
    hm3.dispp();

    cout<<"\nOverloading += Operator...\n"<<endl;
    house hm4(20),hm5(200);
    hm5 += hm4;
    hm5.dispp();

    cout<<"\nOverloading -= Operator...\n"<<endl;
    house hm6(20),hm7(2);
    hm6 -= hm7;
    hm6.dispp();

    cout<<"\nOverloading *= Operator...\n"<<endl;
    house hm8(20),hm9(2);
    hm8 *= hm9;
    hm8.dispp();

    cout<<"\nOverloading /= Operator...\n"<<endl;
    house hm10(20),hm11(2);
    hm10 /= hm11;
    hm10.dispp();

    cout<<"\nOverloading == Operator...\n"<<endl;
    house hm12(20),hm13(20);
    if(hm12 == hm13)
    {
        cout<<"Equal"<<endl;
    }
    else{
        cout<<"Not Equal"<<endl;
    }

    cout<<"\nOverloading && Operator...\n"<<endl;
    house hmm(20,2),hmm2(10,0);
    if(hmm&&hmm2)
    {
        cout<<"True"<<endl;
    }
    else
        cout<<"False"<<endl;

    cout<<"\nOverloading Post Increment Operator...\n"<<endl;
    house in(10);
    (in++).dispp();

    cout<<"\nOverloading Post Increment Operator...\n"<<endl;
    in--;
    in--;
    in.dispp();
    cout<<"\nOverloading Pre Increment Operator...\n"<<endl;
    ++in;
    in.dispp();

    cout<<"\nOverloading Pre Increment Operator...\n"<<endl;
    --in;
    in.dispp();


    return 0;
}
