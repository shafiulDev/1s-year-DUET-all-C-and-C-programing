#include <stdio.h>

struct Name{
	char a;
	int roll;
	int reg;
};
//This function is provide call by refarence by simple use ```````````````````````````````;
void callByRefarance(int *a, int *b){
  *a=*a+*b;
  *b=*a-*b;
  *a=*a-*b;
 printf("a and b value is =%d   %d \n",*a,*b);
 }


//call by raferance in passing a array in a function in my codding````````````````````;
void display( int *a){
	printf("%d ",*a);
	}





int main(){
	int a=12,b=2;
	printf("Previous value is =%d  %d \n",a,b);
	callByRefarance(&a,&b);



	int d[]={2,32,43,42,7,9,0,3,35,4,34,3,2};
	printf("array is :");
	for(int i=0; i<=9; i++){
		display(&d[i]);
	}

	int len=sizeof(d)/sizeof(d[0]);
	printf("\n%d",len);


struct Name s1,s2;

printf("Enter your roll: ");
scanf("%d",&s1.roll);

return 0;
}


