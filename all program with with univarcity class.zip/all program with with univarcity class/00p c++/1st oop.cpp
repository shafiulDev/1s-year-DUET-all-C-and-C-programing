#include <bits/stdc++.h>
using namespace std;
class School{
protected:
	int roll,reg;
	float cgpa;
public:
	School():roll(0),reg(0),cgpa(0){}
	School(int ro, int re, float cg):roll(ro),reg(re),cgpa(cg){}

		void display(){
		cout<<"Roll: "<<roll<<endl;
		cout<<"Registration no: "<<reg<<endl;
		cout <<"CGPA: "<<cgpa<<endl<<endl;
		}

};
class diploma: public School{
protected:
	float dipCgpa;
public:
	diploma(int ro, int reg, float cgpa,float dic ):School(ro,reg,cgpa){
	dipCgpa=dic;}//Must be given for inheritation.

	void display(){
		cout <<"Diploma CGPA: "<<dipCgpa<<endl;
		School::display();//This is very crazy system for overRiding
	}
};
class Undergratuate: public diploma{
protected:
	float ungraCGPA;
public:
	Undergratuate(int ro, int reg, float cgpa, float dis,float un): diploma(ro,reg,cgpa,dis){
	ungraCGPA= un;
	}
		void display(){
		cout <<"Ungratuate CGPA: "<<ungraCGPA<<endl;
		diploma::display();

	}

};

int main(){
	School karim(1,897897,4.98);
	diploma Sakil(902791, 897193,3.45,3.86);
	Undergratuate Shafiul(214059, 4545,3.45,3.86,3.95);


	karim.display();

	Sakil.display();

	Shafiul.display();



}
