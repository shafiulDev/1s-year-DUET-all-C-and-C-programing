#include <bits/stdc++.h>
using namespace std;
class Village{
protected:
int men, women;
friend int operator -=(Village &tem,int tem2);

public:
	Village():men(0),women(0){}
	Village(int m):men(m){}
	Village(float w):women(w){}
//////////////////////////////////////////////
	Village operator +=(int tem ){
		men+=tem;
		return men;
	}
	void Display(){
	cout<<" village peaple  "<<men<<endl;

	}

};
 ////////////////////////////////////////////////////
int operator-=(Village &tem,int tem2){

	tem.men-=tem2;

	return tem.men;
}

int main(){
	Village v1(100000);
	Village v2(10000);
	 v1+=1054;
	 v2-=999;
	 cout<<"FOr men";
	v1.Display();
	cout<<"For women";
	v2.Display();


}
