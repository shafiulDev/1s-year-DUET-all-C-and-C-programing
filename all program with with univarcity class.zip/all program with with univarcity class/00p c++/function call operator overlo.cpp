#include<bits/stdc++.h>
using namespace std;

class Match{
 int bd;

 public:
 	Match():bd(0){}
 	Match(int b):bd(b){}


 	void Display(){
 	cout<<"Bangladesh total run is: "<<bd<<endl<<endl;
 	}
///////////////////->///////////////////////()///////////////////////////
 	Match *operator ->(){
 	return this;}

 	Match operator ()(int  rn){
 		cout<<"This especial Operator overloading "<<endl;
		bd=rn;
		return *this;
 	}

};
int main(){
	Match bangla(550);

	bangla->Display();
	bangla(400);
	bangla.Display();
}
