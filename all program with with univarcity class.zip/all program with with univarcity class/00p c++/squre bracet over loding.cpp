#include<bits/stdc++.h>
using namespace std;
class School{
	int roll[5];
public:
	School(int a,int b, int c,int d, int e){
	roll[0]=(a);
	roll[1]=(b);
	roll[2]=(c);
	roll[3]=(d);
	roll[4] =(e);}

////////////////////////////////////////
	int operator [](int position){
		return roll[position];
	}
};
int main(){
	School one(5,4,8,7,1);

	for (int i=0; i<=4; i++){
		cout<<one[i]<<"  ";
	}


return 0;
}

