#include <bits/stdc++.h>
using namespace std;
int main(){
	int a;
	cout<<"Enter a digit: ";
	cin>>a;
	int learge=0;
	while(a!=0){
		int r=a%10;
		a=a/10;
		if (learge<r){
			learge=r;
		}

	}

	switch(learge){
	case 9:
		cout<<"Nine is Leargest number,";
		break;
	case 1:
		cout<<"One is Leargest number,";
		break;
	case 2:
		cout<<"Two is Leargest number,";
		break;
	case 3:
		cout<<"Three is Leargest number,";
		break;
	case 4:
		cout<<"Four is Leargest number,";
		break;
	case 5:
		cout<<"Five is Leargest number,";
		break;
	case 6:
		cout<<"Six is Leargest number,";
		break;
	case 7:
		cout<<"Seven is Leargest number,";
		break;
	case 8:
		cout<<"Eight is Leargest number,";
		break;

	default:
		cout<<"Zero is a learge Number";
	}

}
