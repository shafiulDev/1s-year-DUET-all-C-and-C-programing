#include <bits/stdc++.h>
using namespace std;

int main(){
	int tc ,n;
	cin>>tc;
	for(int i=0; i<tc; i++){
		cin>>a>>b>>c,

		if((a+b==c)||(b+c==a)||(a+c==b)){
			cout<<"YES";
		}
		else
			cout<<"NO"

	}
	return 0;

}

