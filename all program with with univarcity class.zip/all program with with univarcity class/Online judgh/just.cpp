
#include <bits/stdc++.h>
using namespace std;

int main(){
	int tc;
	cin>> tc,
	for(int i=1; i<=tc; i++){
		if()
	}



	return 0;

}

