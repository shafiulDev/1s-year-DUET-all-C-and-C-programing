#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int main(){
	char a, b[100],sen[222];

	scanf("%c",&a);
	scanf("%s",&b);
	scanf("\n");

	scanf("%[^\n]%*c", &sen);


	printf("%c\n%s\n",a,b);
	printf("%s",sen);
	return 0;
}
