#include <bits/stdc++.h>
#include<math.h>
using namespace std;

int main(){

	int a,b,c;

	for(;;){
			cin>>a>>b>>c;
			if(a==0&& b==0 && c==0)
				cout<<"\n";
			else if((pow(a,2)+pow(b,2))==pow(c,2))
				cout<<"right\n";
			else
				cout<<"wrong\n";

	}

	return 0;

}
