#include <bits/stdc++.h>
using namespace std;

int main(){
	int tc,m,palin,ren,revarse=0;
	cin>>tc;
	for(int i=1; i<=tc;  i++){
		cin>>palin;
		ren=palin;
		while(palin !=0){
			m=palin % 10;
			palin=palin/10;
			revarse=(revarse*10)+m;
			}

		if(ren==revarse){
			cout<<"Case "<<i<<": "<<"Yes\n";
		}
		else{
			cout<<"Case "<<i<<": "<<"No\n";
		}
		revarse=0;
	}
	return 0;

}

