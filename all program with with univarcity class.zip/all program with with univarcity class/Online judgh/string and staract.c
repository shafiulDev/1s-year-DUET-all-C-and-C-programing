#include <stdio.h>
struct distance
{
    int hf;
    float hi;
};
void distanceAddition(struct distance *d1,struct distance *d2)
{
    float inSum = d1->hi + d2->hi;
    int hAdd = inSum / 12;
    d1->hf = (d1->hf + d2->hf) + hAdd;
    inSum -= hAdd*12;
    d1->hi = inSum;
}
int main()
{

    struct distance d1,d2;
    printf("Enter 1st distance\nEnter feet: ");
    scanf("%d",&d1.hf);
    printf("Enter inch: ");
    scanf("%f",&d1.hi);
    printf("Enter 2nd distance\nEnter feet: ");
    scanf("%d",&d2.hf);
    printf("Ener inch: ");
    scanf("%f",&d2.hi);
    distanceAddition(&d1,&d2);
    printf("Sum of distance = %d' - %.2f\"\n",d1.hf,d1.hi);
    return 0;
}
