#include<iostream>
using namespace std;

int main(){
	int a , b, n,sum;
	cin>>n;
	for(int i=1; i<=n; i++){
		cin>>a;
		cin>>b;
		sum=a+b;
		cout<<sum<<endl;
	}

}
