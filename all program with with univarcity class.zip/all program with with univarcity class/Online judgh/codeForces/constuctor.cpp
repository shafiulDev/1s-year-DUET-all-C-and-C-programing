#include<iostream>
#include<conio.h>
using namespace std;
class Student{
	public:
		int id;
		double gpa;

		Student(int x, double y){//it's call constructor
			id=x;
			gpa=y;
		}
		Student(){
		cout<<"Default Constrator";}
		void display(){
		cout<<id<<endl<<gpa;
		}

};

int main(){
	Student shafiul(12,4.34);


	Student anu;
	shafiul.display();




	getch();
		}
