#include<iostream>
#include<conio.h>
using namespace std;
class Student{
	public:
		int id;
		double gpa;


};





int main(){
	Student shafiul;

	shafiul.id=10;
	shafiul.gpa=4.00;

	cout<<shafiul.id<<shafiul.id;



	getch()
		}
