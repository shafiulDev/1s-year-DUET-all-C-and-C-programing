#include<iostream>
#include<conio.h>
using namespace std;
class Student{
	public:
		int id;
		double gpa;

		void display(){
		cout<<id<<endl<<gpa;
		}

		void setvalue(int x, double y){
			id=x;
			gpa=y;
		}

};

int main(){
	Student shafiul,anuva;


	shafiul.setvalue(12,4.34);
	shafiul.display();

	anuva.setvalue(13,4.39);
	anuva.display();



	getch();
		}
