//#include <bits/stdc++.h>
//using namespace std;
//
//int main(){
//	long long int n, q=1,p=1;
//	cin>>n;
//	int stor=n;
//for ( int i=1; i<=n; i++){
//	p=p*2;
//}
//	q=n*n;
//
//	cout<<p<<"\n"<<q;
//	if(p>q)
//		cout<<"Yes";
//	else
//		cout<<"No";
//
//	return 0;
//
//}
//
//

#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int n;
    cin >> n;

    if (pow(2, n) > pow(n, 2)) {
        cout << "Yes" << endl;
    } else {
        cout << "No" << endl;
    }
    return 0;
}
