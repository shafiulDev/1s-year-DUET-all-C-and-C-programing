#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int main(){
	char a, b[50],sen[112];

	scanf("%c",&a);
	scanf("%s",&b);
	scanf("%[^\n]s", &sen);


	printf("%c\n %s \n",a,b);
	printf("%s",sen);
	return 0;
}
