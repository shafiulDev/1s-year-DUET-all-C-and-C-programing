#include <iostream>
#include <bitset>

using namespace std;

int main() {
    int num, i;
    bitset<10> numbers; // a bitset to store the presence of numbers in the range of 1 to 10

    cout << "Enter 9 numbers between 1 to 10: " << endl;
    for (i = 0; i < 9; i++) {
        cin >> num;
        if (num >= 1 && num <= 10) {
            numbers[num-1] = 1;
        } else {
            cout << num << " is not between 1 and 10." << endl;
        }
    }

    // Find the missing number
    for (i = 0; i < 10; i++) {
        if (numbers[i] == 0) {
            cout << "The missing number is: " << i + 1 << endl;
            break;
        }
    }

    return 0;
}
