#include <iostream>
using namespace std;
int main(){
	int n,r,fact1=1,fact2=1;
	float result;
	cout<<"Enter the value of n: ";
	cin>>n;
	cout<<"Enter the value of r: ";
	cin>>r;
	if(n<r){
		cout<<"Pleace given your value n>r";
	}
	else{
			for(int i=1; i<=n; i++){
				fact1=fact1*i;}
			for(int i=1; i<=(n-r); i++){
				fact2=fact2*i;}

		result=fact1/fact2;



	}
	cout<<"The result is: "<<result;
	return 0;
}
int fact(int a){
	fac=+
	for(int i=1; i<=a; i++){

	}

}
