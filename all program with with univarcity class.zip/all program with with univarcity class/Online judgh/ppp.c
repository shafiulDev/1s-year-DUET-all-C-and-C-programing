#include <stdio.h>
int main(){
	int i, j;
	for(i=1; i<=5 ; i++){
		for( j=i; j<5; j++){
			printf(" ");
		}
		int c1=6-i;
		int c2=4;
		for(int k=1; k<=i; k++){
				printf("%d",c1);
				c1++;
			}
		if(i>1){
			for(int l=1; l<i; l++){
					printf("%d",c2);
					--c2;
				}
			}

		printf("\n");

	}
return 0;

}
