
#include<stdio.h>
int main(){
	int i, student[150],count[100];

	for(i=0;i<=10; i++){
		scanf("%d",&student[i]);

	}
	 for (int i = 0; i < 10; i++) {
		int index = student[i] / 10;
		count[index]++;
	  }
	  for (int i = 0; i < 11; i++) {
		printf("%d-%d: %d\n", i*10, (i*10)+9, count[i]);
	  }

}
