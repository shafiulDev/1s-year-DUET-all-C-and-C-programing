#include <iostream>
using namespace std;

int main(){
	int n, a[40],b[20],copyNum;
	int d=0;
	cin>>n;
	for(int i=0; i<n; i++){
		cin>>a[i];
	}


	copyNum=0;
	for(int i=0; i<n; i++){
		for(int j=0; j<n; j++){
				if(j!=i){
					if(a[i]==a[j]){
					copyNum++;
					do{
						c[d]=a
					}


				cout<<"  "<<" "<<i<<endl;
				}
			}}

			b[i]=copyNum;
			copyNum=0;
		}


	int learger=b[0];
	for(int i=0; i<n; i++){
		if(b[i]>learger){
			learger=b[i];
		}
	}

cout<<learger+1;


}

