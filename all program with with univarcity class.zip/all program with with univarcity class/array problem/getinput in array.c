#include <stdio.h>
int main(){
	int i, j, a[4][3];

	for(i=0 ; i<4; i++){
		for(j=0; j<3; j++){
			scanf("%d",&a[i][j]);
		}
	}
return 0;

}
