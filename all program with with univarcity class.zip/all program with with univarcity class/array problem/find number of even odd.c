
#include <stdio.h>
int main(){
	int n, a[20] ,even=0,odd=0;

	scanf("%d",&n);
	for (int i=0; i<n; i++){
		scanf("%d",&a[i]);
	}

	for(int j=0; j<n; j++){
		if(a[j]%2==0){
			even++;
		}
		else
			odd++;
	}

	printf(" Number of even: %d\n",even);
	printf(" Number of odd: %d",odd);

	return 0;
	 }


