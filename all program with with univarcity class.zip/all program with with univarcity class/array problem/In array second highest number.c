#include <stdio.h>
int main(){
	int n, a[20] ,even=1,odd=1;

	scanf("%d",&n);
	for (int i=0; i<n; i++){
		scanf("%d",&a[i]);
	}

	for(int j=0; j<n; j++){
		if(a[j]%2==0){
			even++;
		}
		else
			odd++;
	}

	printf(" Number of even: %d",even);
	printf(" Number of odd: %d",odd);

	return 0;
	 }




//#include <stdio.h>
//int main(){
//	int n, a[20] ,leargest2;
//
//	scanf("%d",&n);
//	for (int i=0; i<n; i++){
//		scanf("%d",&a[i]);
//	}
//	 int leargest= a[0];
//	 for(int j=1 ; j<n; j++){
//		if(a[j]>leargest){
//			leargest=a[j];
//
//		}
//	 }
//
//	 leargest2=-9999999999999;
//	 for(int k=0;k<n; k++){
//		if (a[k] !=leargest){
//				if(leargest2<a[k]){
//					leargest2=a[k];
//
//			}
//		}
//	 }
//	printf("     %d",leargest2);
//	printf("         %d\n",leargest);
//
//	return 0;
//	 }
