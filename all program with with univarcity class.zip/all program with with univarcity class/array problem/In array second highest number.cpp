#include <iostream>
using namespace std;
int main(){
	int n, a[20] ,learger,learger2;

	cin>>n;
	for (int i=0; i<n; i++){
		cin>>a[i];
	}
	learger=a[0];
	for(int i=1; i<n; i++){
		if(a[i]>learger){
			learger=a[i];
		}
	}
	 learger2=-9999999999999;
	 for(int k=0;k<n; k++){
		if (a[k] !=learger){
				if(learger2<a[k]){
					learger2=a[k];

			}
		}
	 }
	int learger3=-9999999999999;
	 for(int k=0;k<n; k++){
		if (a[k] !=learger && a[k] !=learger2){
				if(learger3<a[k]){
					learger3=a[k];

			}
		}
	 }

	 cout<<"First learger= "<<learger<<endl;
	 cout<<"Second Lerger= "<<learger2<<endl;
	 cout<<"Third Lerger= "<<learger3;


	 }

