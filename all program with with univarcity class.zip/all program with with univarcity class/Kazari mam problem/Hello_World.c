#include <stdio.h>
int main(){
int a,b, sum=0;
a=12;
b=5;
sum=a+b;
printf("the value is= %d",sum);

}
