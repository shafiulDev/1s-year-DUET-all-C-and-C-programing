#include <stdio.h>
int main(){
	int n, i, j,a[3][3];
	char cha='A';

	for(i=0; i<=2; i++){
		for(j=0; j<=2; j++){
			scanf("%d",&a[i][j]);
		}
	}
	int ran=a[0][0];
	a[0][0]=a[0][2];
	a[0][2]=ran;

	ran=a[2][0];
	a[2][0]=a[2][2];
	a[2][2]=ran;
	for(i=0; i<=2; i++){
		for(j=0; j<=2; j++){
			printf("%d",a[i][j]);
		}
		printf("\n");
	}

	return 0;
}

