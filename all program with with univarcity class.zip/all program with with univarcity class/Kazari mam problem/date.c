#include <stdio.h>
int next_func(int d);
int next_manth(int date,int m);
int main(){
    int date,manth,year,i,next_date,next_manth;


    printf("Enter the value of date:");
    scanf("%d%d",&date,&manth);


    next_date=next_func(date);
    printf("Next date:%d\n",next_date);


    next_manth=manth_func(manth,next_date);
    printf("Next manth:%d",next_manth);

}



 int next_func(int d){
     int date;
     for(int i=1; i<=31;i++){
     if(d>0&&d<31){
        date=d+1;
        }
     else if(d==31){
        date=1;
     }
     else
        {
       date=0;
     }
     }
    return date;

 }





int manth_func(int m,int date){
    int manth;
       if(m==4||m==6||m==9||m==11){
        if(date==30){
            manth=m+1;
            }
            else{
                manth=m;
            }
        }

        else if(m==1||m==3||m==7||m==8||m==10){
                if(date==31){
                    manth=m+1;
                }
                else{
                    manth=m;
                }
        }
        else{
            manth=m;
            }


    return manth;
}

