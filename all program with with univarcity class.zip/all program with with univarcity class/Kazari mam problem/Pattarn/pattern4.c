#include <stdio.h>
int main(){
    int row, col, n;
    scanf("%d",&n);


    for(row=1; row<=n; row++ ){
        for(col=1; col<=row; col++){
                if((col+row)%2==0)
                    printf("AA");
                else
                    printf("BB");

        }
        printf("\n");
    }
    return 0;
}
