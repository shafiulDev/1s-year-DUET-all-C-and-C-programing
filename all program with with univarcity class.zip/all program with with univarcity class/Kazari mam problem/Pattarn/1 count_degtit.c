#include <stdio.h>
int main(){
	int n, count=0;
	printf("Enter a number = ");
	scanf("%d",&n);

	while(n){
		n/=10;
		count++;
	}
	printf("Total number of digit = %d",count);
	return 0;
}
