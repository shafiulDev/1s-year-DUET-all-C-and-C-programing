#include <stdio.h>
 int main(){
	int i,j,k, n
	printf("Enter the value of n");
	scanf("%d",&n);

	for(i=1; i<=n/2+1; i++){
		for(j=i; j<n/2+1; j++){
			printf(" ");
		}
		for (k=1; k<=2*i-1; k++){
			printf("*");
		}
		printf("\n");
	}

 }

