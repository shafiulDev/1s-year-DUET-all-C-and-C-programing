
#include <stdio.h>
int main(){
    int row, col, n,i;
    scanf("%d",&n);

    for(row=1; row<=n; row++ ){
        for(col=row; col<=n-1; col++){
            printf(" ");
        }
        for(i=1; i<=row;i++){
             printf("*");
        }
        printf("\n");
    }
    return 0;
}
