
#include <stdio.h>
int main(){
    int n,s, p=1,sum=0;
printf("Enter your number:");
    scanf("%d",&n);

    while(n!=0){

        s=n%10;
        n=n/10;
        sum=sum+s;
    }
    printf("%d",sum);

    return 0;
}
