
#include <math.h>
int main(){
    int n,s, p=0,sum=0,ren;
printf("Enter your number:");
    scanf("%d",&n);
    ren=n;
    while(n!=0){
        n=n/10;
        p++;
    }
    n=ren;
    while(n!=0){
        s=n%10;
        n=n/10;
        sum=sum+pow(s,p);
    }


    if (sum==ren){
        printf("this is armstong");
    }
    else
        printf("Not armstong");
    return 0;
}

