#include <stdio.h>
int main(){
	int n, i, j, count=1;
	char cha='A';

	for(i=1; i<=4; i++){
		for( j=1; j<=5; j++){
			if(i==1||i==4)
				printf("*");
			else{
				if(j==1||j==5)
					printf("*");
				else
					printf(" ");
			}
		}

	printf("\n");

		}
	return 0;
}

