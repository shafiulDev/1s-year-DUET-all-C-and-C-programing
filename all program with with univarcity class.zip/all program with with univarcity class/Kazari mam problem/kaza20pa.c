#include <stdio.h>
int main(){
	int n, i,count, j,k;
	scanf("%d",&n);
	count=1;
	for(i=1; i<=n; i++){
		for(j=i; j<=n/2; j++){
			printf("*");

		}
		if(i>1&&count<6){
			for(k=1; k<=count*2; k++){
				printf(" ");

			}
					count++;
		}
		for(j=i; j<=n/2; j++){
			printf("*");

		}
		printf("\n");

		}
return 0;
}


