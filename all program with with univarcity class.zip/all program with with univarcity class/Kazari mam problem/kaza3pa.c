#include <stdio.h>
int main(){
	int n, i, j;
			int count=5;
//scanf("%d",&n);// type first value is 9
	for(i=1; i<10; i++){
		for( j=1; j<i; j++){
				printf(" ");
		}
		for(int k= (12/2)-i; k>1; k--){
			printf("%d",k);
		}

		for( int s=1; s<=count; s++){
				printf("%d",s);
		}
		count--;
		printf("\n");
	}
return 0;

}
