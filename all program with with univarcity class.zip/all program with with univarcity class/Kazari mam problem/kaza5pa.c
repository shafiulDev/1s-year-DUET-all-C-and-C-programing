#include <stdio.h>
int main(){
	int n, i, j, count, print;
	count=7;
	for(i=0; i<=3; i++){

		if(i==0)
			printf("%d",count);
		else{
			count =count*2;
			print=count;
			for( j=1; j<=pow(2,i); j++){
				printf("%d ",print);
				print++;
			}
		}
		printf("\n");
	}
			return 0;

}
