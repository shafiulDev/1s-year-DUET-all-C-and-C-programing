#include <stdio.h>
int main(){
	int n, i, j;
	scanf("%d",&n);

	for(i=1; i<=n; i++){
		for(j=1; j<=i; j++){
			if(j>1&&j<=n)
				printf("*");
			if(j%2==0||j%2==1)
				printf("%d",i);
		}
		printf("\n");
	}


	for(i=n; i>=1; i--){
		for(j=1; j<=i; j++){
			if(j>1&&j<=n)
				printf("*");
			if(j%2==0||j%2==1)
				printf("%d",i);
		}
		printf("\n");
	}
return 0;

}
