#include <stdio.h>
int main(){
	int i, j,n,c1,c2;
	printf ("Enter A integer number for Pattern: ");
	scanf("%d",&n);

	for(i=1; i<=n ; i++){
		for( j=i; j<n; j++){
			printf(" ");
		}
		c1=(n+1)-i;
		c2=n-1;
		for(int k=1; k<=i; k++){
				printf("%d",c1);
				c1++;
			}
		if(i>1){
			for(int l=1; l<i; l++){
					printf("%d",c2);
					--c2;
				}
			}

		printf("\n");

	}
return 0;

}
