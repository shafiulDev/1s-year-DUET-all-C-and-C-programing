#include <stdio.h>
int main(){
	int n, i, j, count=1;
	char cha='A';

	for(i=1; i<=5; i++){
		for( j=1; j<=i; j++){
			if(i%2==1){
				if(j%2==1){
					printf("%d",j);
				}
				else
					printf("*");
			}
			else{
				if(j%2==1)
					printf("*");
				else
					printf("%d",j);
			}
		}

		printf("\n");

		}
return 0;
}

