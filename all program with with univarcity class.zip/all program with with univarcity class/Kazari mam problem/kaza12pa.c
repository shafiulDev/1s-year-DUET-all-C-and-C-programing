#include <stdio.h>
int main(){
	int n, i, j, count=1;
	char cha='A';

	for(i=1; i<=5; i++){
		for( j=1; j<=i; j++){
			if(i%2==1){
				printf("%d",count);
				count++;
			}
			else{
				printf("%c",cha);
				cha++;
				}
		}

		printf("\n");

		}
return 0;
}

